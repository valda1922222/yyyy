![LickingT](https://raw.githubusercontent.com/fuckyoustan/Licking-Thermal/refs/heads/main/banner.jpg)

## Licking Thermal 💦

Yo! Licking Thermal is a Magisk module that auto kills thermal throttling whenever your run games and brings it back once you’re done.  Perfect if you wanna squeeze every bit of power outta your phone and keep your gameplay smooth AF

## ✨ Features

- 🚀 Auto Thermal Killer  
  Turns off thermal throttling when any app from your custom list is open, and turns it back on when you exit

- 🧠 No More Power Limits  
  Bypasses GPU/CPU power limiters so you get max performance even when things get hot

- 🛠 Disable Thermal Zone
  Forces thermal zones into userspace mode meaning less random slowdowns

- 🔒 HAL Locker  
  Temporarily locks thermal HAL so it can’t mess with performance

- 🔔 Live Status Notifs  
  Pops a notification every time thermal gets disabled or restored so you know it’s working

## 📥 Download

[<img src="https://github.com/machiav3lli/oandbackupx/blob/034b226cea5c1b30eb4f6a6f313e4dadcbb0ece4/badge_github.png"
    alt="Get it on GitHub"
    height="80">](https://github.com/fuckyoustan/Licking-Thermal/releases)

## 📂 How to Use

1. Flash this module through Magisk
2. Edit list.txt in the module if the app package you using is not available

## ⚠️ WARNING

> [!CAUTION]
> THIS MODULE DISABLES TEMPERATURE PROTECTION! THE RISK OF OVERHEATING, HARDWARE DAMAGE, OR OTHER DANGERS IS 100% YOUR RESPONSIBILITY. USE AT YOUR OWN RISK!
<hr/>
